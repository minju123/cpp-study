#include<iostream>
#include <ctime>
#include <cstdlib>

using namespace std;

int main() {
	srand(time(NULL));
	int a[5];
	for (int i = 0; i < 5; i++) {
		a[i] = rand() % 100;
		cout << a[i] << " ";
	}
	return 0;
}