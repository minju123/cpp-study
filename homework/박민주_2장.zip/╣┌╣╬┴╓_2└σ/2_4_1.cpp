#include <iostream>
#include <cstring>

using namespace std;

int main() {

	char a[20] = "abcdef";
	char b[20] = "ghijkl";
	char c[100];

	cout << strlen(a) << endl;
	strcat_s(a, b);
	cout << a << endl;
	strcpy_s(c, b);
	cout << c << endl;
	if (strcmp(a, c)) {
		cout << "same" << endl;
	}
	else {
		cout << "different" << endl;
	}
	return 0;
}