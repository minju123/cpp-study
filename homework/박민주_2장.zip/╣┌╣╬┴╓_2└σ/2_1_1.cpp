#include <iostream>

using namespace std;

void add(int& num) {
	num++;
}

void change(int& num) {
	num = num * -1;
}

int main() {
	int num;
	cout << "put num : ";
	cin >> num;

	add(num);
	cout << num << endl;
	change(num);
	cout << num << endl;
	return 0;
}